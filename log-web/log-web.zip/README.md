release_1.0:
实现了权限管理；

