﻿
// 本地开发环境
var baseUrl              =      "http://localhost:9002/log/";

//var baseUrl              =      "http://192.168.11.223:9002/log/";

// 测试环境
// var baseUrl              =       "http://47.102.126.118:9002/log/";